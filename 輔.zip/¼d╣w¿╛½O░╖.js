(function (){
	let ccc=document.URL;
	let bureauRecordNo="";
	cont=false;
	if (ccc=='https://phpcis.chshb.gov.tw/registration'){
		let tb=document.getElementById('registrationList').querySelector('table');
		for (let i=1;i<tb.rows.length;i++){
			if (tb.rows[i].cells[0].children[0].checked){
				bureauRecordNo=tb.rows[i].cells[2].textContent;
				cont=true;
				break;
			}
		}
	} else if (ccc=='https://phpcis.chshb.gov.tw/registration/create'){
		bureauRecordNo=document.querySelector('[name="bureauRecordNo"]').value;
		cont=true;
	} else if (ccc.includes('https://phpcis.chshb.gov.tw/registration/')){
		bureauRecordNo=document.querySelector('[name="bureauRecordNo"]').value;
		cont=true;
	} 
	if (cont){
		const xhr = new XMLHttpRequest();
		const caseurl='https://phpcis.chshb.gov.tw/api/v1/personal_infos/list?bureauRecordNo='+bureauRecordNo;
		xhr.open("GET", caseurl, false);
		xhr.send();
		const resu=JSON.parse(xhr.responseText).result[0];
		getvaccineviaid(resu);
		const personalInfoId=resu.personalInfoId;
		const gender=resu.gender;
		const birY=resu.birthday.split('-')[0];
		const nowy=new Date().getFullYear();
		const age=(nowy-birY)*1;
		
		const preventationurl='https://phpcis.chshb.gov.tw/api/v1/personal_infos/preventions_histories/list?personalInfoId='+personalInfoId;
		xhr.open("GET", preventationurl, false);
		xhr.send();
		const preres=JSON.parse(xhr.responseText).result;
		
		let HE=['HE'];
		let FO=['FO'];
		let OR=['OR'];
		let PA=['PA'];
		let MA=['MA'];
		for (let i=1;i<=preres.length;i++){
			if (preres[preres.length-i].preventionTag=='02'){
				if (preres[preres.length-i].serviceCode.includes('Y')){
					HE.splice(HE.length-1,1);
				} else {
					HE.push(preres[preres.length-i]);
				}
			} else if (preres[preres.length-i].preventionTag=='03'){
				if (preres[preres.length-i].serviceCode.includes('Y')){
					PA.splice(PA.length-1,1);
				} else {
					PA.push(preres[preres.length-i]);
				}
			} else if (preres[preres.length-i].preventionTag=='06'){
				if (preres[preres.length-i].serviceCode.includes('Y')){
					MA.splice(MA.length-1,1);
				} else {
					MA.push(preres[preres.length-i]);
				}
			} else if (preres[preres.length-i].preventionTag=='07'){
				if (preres[preres.length-i].serviceCode.includes('Y')){
					FO.splice(FO.length-1,1);
				} else {
					FO.push(preres[preres.length-i]);
				}
			} else if (preres[preres.length-i].preventionTag=='08'){
				if (preres[preres.length-i].serviceCode.includes('Y')){
					OR.splice(OR.length-1,1);
				} else {
					OR.push(preres[preres.length-i]);
				}
			}
		}
		
		if (age>=65){
			if (HE.length>1){
				LHE=HE[HE.length-1].treatmentDate.split('-')[0];
				if (nowy-LHE>=1){
					HEC='O , >65歲每年1次';
				} else {
					HEC='X , >65歲未滿1年';
				}
				theclinic=HE[HE.length-1].clinicName;
				theclinic=theclinic.replace('彰化基督教醫療財團法人', '').replace('秀傳醫療社團法人', '')
				if (theclinic.length>12){
					theclinic=theclinic.substring(theclinic.length-12,theclinic.length)
				}
				HEC=HEC+','+theclinic+'('+cytomky(HE[HE.length-1].treatmentDate)+')';
			} else {
				HEC='O , >65歲每年1次';
			}
		} else if (age>=40 && age<65){
			if (HE.length>1){
				LHE=HE[HE.length-1].treatmentDate.split('-')[0];
				theclinic=HE[HE.length-1].clinicName;
				theclinic=theclinic.replace('彰化基督教醫療財團法人', '').replace('秀傳醫療社團法人', '')
				if (nowy-LHE>=3){
					HEC='O , 40-64歲3年1次'+theclinic+'('+cytomky(HE[HE.length-1].treatmentDate)+')';
				} else {
					HEC='X , 40-64歲未滿3年'+theclinic+'('+cytomky(HE[HE.length-1].treatmentDate)+')';
				}
			} else {
				HEC='O , 40-65歲3年1次';
			}
		} else if (age>=30 && age<40){
			if (HE.length>1){
				LHE=HE[HE.length-1].treatmentDate.split('-')[0];
				theclinic=HE[HE.length-1].clinicName;
				theclinic=theclinic.replace('彰化基督教醫療財團法人', '').replace('秀傳醫療社團法人', '')
				if (nowy-LHE>=5){
					HEC='O , 30-39歲5年1次'+theclinic+'('+cytomky(HE[HE.length-1].treatmentDate)+')';
				} else {
					HEC='X , 30-39歲未滿5年'+theclinic+'('+cytomky(HE[HE.length-1].treatmentDate)+')';
				}
			} else {
				HEC='O , 30-39歲5年1次';
			}
		} else {
			HEC='X , <30歲不可成健';
		}
		if (gender=='2'){
			if (age>=30){
				if (PA.length>1){
					LPA=PA[PA.length-1].treatmentDate.split('-')[0];
					if (nowy-LPA>=6){
						PAC='O , >30歲6年未抹';
					} else if (nowy-LPA>=3 && nowy-LPA<6){
						PAC='O , >30歲3年未抹';
					} else if (nowy-LPA>=1){
						PAC='O , >30歲每年1次';
					} else if (nowy-LPA<1){
						PAC='X , >30歲未滿1年';
					} 
					theclinic=PA[PA.length-1].clinicName;
					theclinic=theclinic.replace('彰化基督教醫療財團法人', '').replace('秀傳醫療社團法人', '')
					if (theclinic.length>12){
						theclinic=theclinic.substring(theclinic.length-12,theclinic.length)
					}
					PAC=PAC+','+theclinic+'('+cytomky(PA[PA.length-1].treatmentDate)+')';
				} else {
					PAC='O , 不曾抹(首篩)';
				}
			} else if (age>=25 && age<30){
				if (PA.length>1){
					LPA=PA[PA.length-1].treatmentDate.split('-')[0];
					if (nowy-LPA>=6){
						PAC='O , 25-30歲6年未抹';
					} else if (nowy-LPA>=3 && nowy-LPA<6){
						PAC='O , 25-30歲3年未抹';
					} else if (nowy-LPA<3){
						PAC='X , 25-30歲未滿3年';
					} 
					theclinic=PA[PA.length-1].clinicName;
					theclinic=theclinic.replace('彰化基督教醫療財團法人', '').replace('秀傳醫療社團法人', '')
					if (theclinic.length>12){
						theclinic=theclinic.substring(theclinic.length-12,theclinic.length)
					}
					PAC=PAC+','+theclinic+'('+cytomky(PA[PA.length-1].treatmentDate)+')';
				} else {
					PAC='O , 不曾抹(首篩)';
				}
			} else {
				PAC='X , <25歲';
			}
		} else {
			PAC='X , 需女性';
		}
		if (gender=='2'){
			if (age>=40 && age<70){
				if (MA.length>1){
					LMA=MA[MA.length-1].treatmentDate.split('-')[0];
					if (nowy-LMA>=2){
						MAC='O , 40-70歲2年1次';
					} else {
						MAC='X , 40-70歲未滿2年';
					}
					theclinic=MA[MA.length-1].clinicName;
					theclinic=theclinic.replace('彰化基督教醫療財團法人', '').replace('秀傳醫療社團法人', '')
					if (theclinic.length>12){
						theclinic=theclinic.substring(theclinic.length-12,theclinic.length)
					}
					MAC=MAC+','+theclinic+'('+cytomky(MA[MA.length-1].treatmentDate)+')';
				} else {
					MAC='O , 40-70歲，不曾乳攝(首篩)';
				}
			} else if (age>=70){
				MAC='X , >70歲';
			} else {
				MAC='X , <40歲';
			}
		} else {
			MAC='X , 需女性';
		}
		if (age>=45 && age<75){
			if (FO.length>1){
				LFO=FO[FO.length-1].treatmentDate.split('-')[0];
				if (nowy-LFO>=2){
					FOC='O , 45-75歲2年1次';
				} else {
					FOC='X , 45-75歲未滿2年';
				}
				theclinic=FO[FO.length-1].clinicName;
				theclinic=theclinic.replace('彰化基督教醫療財團法人', '').replace('秀傳醫療社團法人', '')
				if (theclinic.length>12){
					theclinic=theclinic.substring(theclinic.length-12,theclinic.length)
				}
				FOC=FOC+','+theclinic+'('+cytomky(FO[FO.length-1].treatmentDate)+')';
			} else {
				FOC='O , 45-75歲，不曾FOBT(首篩)';
			}
		} else if (age>=75){
			FOC='X , >75歲';
		} else {
			FOC='X , <45歲;40-44歲詢問家族史';
		}
		if (age>=30){
			if (OR.length>1){
				LOR=OR[OR.length-1].treatmentDate.split('-')[0];
				if (nowy-LOR>=2){
					ORC='O , 有菸檳史可';
				} else {
					ORC='X , 間隔未滿2年';
				}
				theclinic=OR[OR.length-1].clinicName;
				theclinic=theclinic.replace('彰化基督教醫療財團法人', '').replace('秀傳醫療社團法人', '')
				if (theclinic.length>12){
					theclinic=theclinic.substring(theclinic.length-12,theclinic.length)
				}
				ORC=ORC+','+theclinic+'('+cytomky(OR[OR.length-1].treatmentDate)+')';
			} else {
				ORC='O , 有菸檳史可(首篩)';
			}
		} else {
			ORC='X , 未滿30歲';
		}
		let retmsg="";
		retmsg=retmsg+'成健: '+HEC+'\n';
		retmsg=retmsg+'腸篩: '+FOC+'\n';
		retmsg=retmsg+'子抹: '+PAC+'\n';
		retmsg=retmsg+'乳攝: '+MAC+'\n';
		retmsg=retmsg+'口篩: '+ORC+'\n';
		alert(retmsg);
		
	} else {
		alert('請選擇個案')
	}
	
	function cytomky(cy){
		let acy=cy.split('-');
		let cyy=acy[0]-1911;
		let cym=acy[1];
		let cyd=acy[2];
		return cyy+cym+cyd
	}
	function getvaccineviaid(personalinfoobj){
		testmode=false;
		vhurl="https://phpcis.chshb.gov.tw/api/v1/niis/vaccination_history/list?personalInfoId="+personalinfoobj.personalInfoId;
		retjson=JSON.parse(httpGet(vhurl));
		ay=personalinfoobj.birthday.split('-');
		gy=("000"+(ay[0]-1911));
		patientidbirth=gy.substring(gy.length-3,gy.length)+ay[1]+ay[2];
		thename=personalinfoobj.name;
		
		resultobj={
			"Record": [],
			"ApplyRecord": [],
			"VaccRecord": "",
			"Error": ""
		}
		tempobj={};
		for (let i=0;i<retjson.result.length;i++){
			injitem=retjson.result[i];
			if (!(injitem.immuDate in tempobj)){
				tempobj[injitem.immuDate]=[];
			}
			tempobj[injitem.immuDate].push(injitem)
		}
		tempdatelist=Object.keys(tempobj);
		tempdatelist=tempdatelist.sort(); 
		for (let i=0;i<tempdatelist.length;i++){
			idhis=tempobj[tempdatelist[i]];
			for (let j=0;j<idhis.length;j++){
				immuDate=idhis[j].immuDate;
				theY=immuDate.substring(0,3)*1+1911;
				theM=immuDate.substring(3,5);
				theD=immuDate.substring(5,7);
				tempid={
					"SRVC": idhis[j].vaccineID,
					"ID": theY+"-"+theM+"-"+theD+"T00:00:00",
					"ON": idhis[j].immuAgcyName,
					"VB": ""
				}
				resultobj.ApplyRecord.push(tempid);
			}
		}
		vaccinelist=['rHepB-1','rHepB-2','rHepB-3',
			'13PCV-1','13PCV-2','13PCV-3','13PCV-4',
			'5in1-1','5in1-2','5in1-3','5in1-4',
			'BCG',
			'MMR-1','MMR-2',
			'Var-1',
			'2HepA-1','2HepA-2',
			'JE-CV_LiveAtd-1','JE-CV_LiveAtd-2',
			'DTaP-IPV-5'
			]
		vacnameprolist={
	"BCG":["BCG"],
	"rHepB-1":["HBV"],
	"rHepB-2":["HBV"],
	"rHepB-3":["HBV"],
	"5in1-1":["Tetanus","Diphtheria","Pertusis","Polio","Hib"],
	"5in1-2":["Tetanus","Diphtheria","Pertusis","Polio","Hib"],
	"5in1-3":["Tetanus","Diphtheria","Pertusis","Polio","Hib"],
	"5in1-4":["Tetanus","Diphtheria","Pertusis","Polio","Hib"],
	"MMR-1":["Measles","Mumps","Rubella"],
	"MMR-2":["Measles","Mumps","Rubella"],
	"JE-1":["JE"],
	"JE-2":["JE"],
	"JE-3":["JE"],
	"JE-4":["JE"],
	"JE-CV_LiveAtd-1":["JE"],
	"JE-CV_LiveAtd-2":["JE"],
	"JE_LiveAtd-1":["JE"],
	"JE_LiveAtd-2":["JE"],
	"JE-VC_Inactd-1":["JE"],
	"JE-VC_Inactd-2":["JE"],
	"JE-VC_Inactd-3":["JE"],
	"JE-VC_Inactd-4":["JE"],
	"Tdap-IPV":["Tetanus","Diphtheria","Pertusis","Polio"],
	"Td":["Tetanus","Diphtheria"],
	"2HepA-1":["HAV"],
	"2HepA-2":["HAV"],
	"6in1-1":["Tetanus","Diphtheria","Pertusis","Polio","Hib","HBV"],
	"6in1-2":["Tetanus","Diphtheria","Pertusis","Polio","Hib","HBV"],
	"6in1-3":["Tetanus","Diphtheria","Pertusis","Polio","Hib","HBV"],
	"6in1-4":["Tetanus","Diphtheria","Pertusis","Polio","Hib","HBV"],
	"13PCV-1":["PCV"],
	"13PCV-2":["PCV"],
	"13PCV-3":["PCV"],
	"13PCV-4":["PCV"],
	"DTaP-IPV-1":["Tetanus","Diphtheria","Pertusis","Polio"],
	"DTaP-IPV-2":["Tetanus","Diphtheria","Pertusis","Polio"],
	"DTaP-IPV-3":["Tetanus","Diphtheria","Pertusis","Polio"],
	"DTaP-IPV-4":["Tetanus","Diphtheria","Pertusis","Polio"],
	"MV":["Measles"],
	"DTaP-1":["Tetanus","Diphtheria","Pertusis"],
	"DTaP-2":["Tetanus","Diphtheria","Pertusis"],
	"DTaP-3":["Tetanus","Diphtheria","Pertusis"],
	"DTaP-4":["Tetanus","Diphtheria","Pertusis"],
	"DTaP-5":["Tetanus","Diphtheria","Pertusis"],
	"IPV-1":["Polio"],
	"IPV-2":["Polio"],
	"IPV-3":["Polio"],
	"IPV-4":["Polio"],
	"IPV-5":["Polio"],
	"Hib-1":["Hib"],
	"Hib-2":["Hib"],
	"Hib-3":["Hib"],
	"Hib-4":["Hib"],
	"DTP-1":["Tetanus","Diphtheria","Pertusis"],
	"DTP-2":["Tetanus","Diphtheria","Pertusis"],
	"DTP-3":["Tetanus","Diphtheria","Pertusis"],
	"DTP-4":["Tetanus","Diphtheria","Pertusis"],
	"DT-1":["Tetanus","Diphtheria"],
	"DT-2":["Tetanus","Diphtheria"],
	"DT-3":["Tetanus","Diphtheria"],
	"DT-4":["Tetanus","Diphtheria"],
	"7PCV-1":["PCV"],
	"7PCV-2":["PCV"],
	"7PCV-3":["PCV"],
	"7PCV-4":["PCV"],
	"10PCV-1":["PCV"],
	"10PCV-2":["PCV"],
	"10PCV-3":["PCV"],
	"10PCV-4":["PCV"],
	"HepAB-1":["HAV","HBV"],
	"HepAB-2":["HAV","HBV"],
	"HepAB-3":["HAV","HBV"],
	"Tdap":["AP"],
	"+BCG":["BCG"],
	"HepB-LBW":["HBV"],
	"HepB-LBWe":["HBV"],
	"HepB-LBWs":["HBV"],
	"HepB-LBWu":["HBV"],
	"+JE-1":["JE"],
	"+JE-2":["JE"],
	"+Td-1":["Tetanus","Diphtheria"],
	"+Td-2":["Tetanus","Diphtheria"],
	"+Tdap-IPV-1":["AP"],
	"+Tdap-IPV-2":["AP"],
	"+MMR-1":["Measles","Mumps","Rubella"],
	"+MMR-2":["Measles","Mumps","Rubella"],
	"+rHepB-1":["HBV"],
	"+rHepB-2":["HBV"],
	"+rHepB-3":["HBV"],
	"pHepB-1":["HBV"],
	"pHepB-2":["HBV"],
	"pHepB-3":["HBV"],
	"pHepB-4":["HBV"],
	"Mumps":["Mumps"],
	"+MV":["Measles"],
	"OPV-1":["Polio"],
	"OPV-2":["Polio"],
	"OPV-3":["Polio"],
	"OPV-4":["Polio"],
	"OPV-5":["Polio"],
	"+OPV-1":["Polio"],
	"+OPV-2":["Polio"],
	"+OPV-3":["Polio"],
	"+IPV-1":["Polio"],
	"+IPV-2":["Polio"],
	"+IPV-3":["Polio"],
	"DTaP-IPV-5":["AP"],
	"+DTaP-IPV-1":["Tetanus","Diphtheria","Pertusis","Polio","AP"],
	"+DTaP-IPV-2":["Tetanus","Diphtheria","Pertusis","Polio","AP"],
	"MMRV-1":["Measles","Mumps","Rubella","Var"],
	"MMRV-2":["Measles","Mumps","Rubella","Var"],
	"+2HepA-1":["HAV"],
	"+2HepA-2":["HAV"],
	"3HepA-1":["HAV"],
	"3HepA-2":["HAV"],
	"3HepA-3":["HAV"],
	"MMR0":["Measles","Mumps","Rubella"],
	"MR-1":["Measles","Rubella"],
	"MR-2":["Measles","Rubella"],
	"RV":["Rubella"],
	"Var-1":["Var"],
	"Var-2":["Var"],
	"MMR":["Measles","Mumps","Rubella"],
	"15PCV-1":["PCV"],
	"15PCV-2":["PCV"],
	"15PCV-3":["PCV"],
	"15PCV-4":["PCV"],
	"DTaP-HepB-IPV-1":["Tetanus","Diphtheria","Pertusis","Polio","HBV"],
	"DTaP-HepB-IPV-2":["Tetanus","Diphtheria","Pertusis","Polio","HBV"],
	"DTaP-HepB-IPV-3":["Tetanus","Diphtheria","Pertusis","Polio","HBV"],
	"DTaP-HepB-IPV-4":["Tetanus","Diphtheria","Pertusis","Polio","HBV"],
	"DTaP-HepB-IPV-5":["Tetanus","Diphtheria","Pertusis","Polio","HBV","AP"],
	"TT":["Tetanus"],
	"DTwP-HepB-Hib-1":["Tetanus","Diphtheria","Pertusis","Polio","HBV"],
	"DTwP-HepB-Hib-2":["Tetanus","Diphtheria","Pertusis","Polio","HBV"],
	"DTwP-HepB-Hib-3":["Tetanus","Diphtheria","Pertusis","Polio","HBV"],
	"DTwP-HepB-Hib-4":["Tetanus","Diphtheria","Pertusis","Polio","HBV"],
	"DTwP-HepB-Hib-5":["Tetanus","Diphtheria","Pertusis","Polio","HBV","AP"],
	"rHepB":["HBV"],
	"20PCV-1":["PCV"],
	"20PCV-2":["PCV"],
	"20PCV-3":["PCV"],
	"20PCV-4":["PCV"],
	};
		vacprolist=["HBV","Tetanus","Diphtheria","Pertusis","Hib","Polio","PCV","BCG","Measles","Mumps","Rubella","Var","HAV","JE","AP"];
		returnvalue=getvaccinelist(patientidbirth,resultobj);
		showvacwindow(returnvalue,patientidbirth);
		function applyrecord_to_obj(NIISrecord){
			applylistbyvaccine={};
			for (a=0;a<NIISrecord.ApplyRecord.length;a++){
				SRVC=NIISrecord.ApplyRecord[a].SRVC;
				temprecord={};
				temprecord['ID']=NIISrecord.ApplyRecord[a]['ID'];
				temprecord['ON']=NIISrecord.ApplyRecord[a]['ON'];
				temprecord['VB']=NIISrecord.ApplyRecord[a]['VB'];
				temprecord['SRVC']=SRVC;
				applylistbyvaccine[SRVC]=temprecord;
			}
			return applylistbyvaccine
		}
		function countage(BD){
			TBY=BD.substring(0,3)*1;
			TBM=BD.substring(3,5)*1;
			TBD=BD.substring(5,7)*1;
			ND=new Date;
			NY=ND.getFullYear()-1911;
			NM=ND.getMonth()+1;
			ND=ND.getDate();
			DO=ND-TBD;
			MO=NM-TBM;
			YO=NY-TBY;
			if (DO<0){
				DO+=30;
				MO-=1;
			}
			if (MO<0){
				MO+=12;
				YO-=1
			}
			returnvalue=[YO,MO,DO]
			return returnvalue
		}
		function countageold(BD){
			TBY=BD.substring(0,3)*1;
			ND=new Date;
			NY=ND.getFullYear()-1911;
			return NY-TBY
		}
		function countVageold(BD,ID){
			TBY=BD.substring(0,3)*1+1911;
			IDY=new Date(ID).getFullYear();
			return IDY-TBY
		}
		function countVageold2(BD,ID){
			TBY=BD.substring(0,3)*1+1911;
			TBM=BD.substring(3,5)*1;
			TBD=BD.substring(3,5)*1;
			IDY=new Date(ID).getFullYear();
			IDM=new Date(ID).getMonth()+1;
			IDD=new Date(ID).getDate();
			DDY=IDY-TBY;
			DDM=IDM-TBM;
			DDD=IDD-TBD;
			if (DDD<0){
				DDD+=30;
				DDM-=1;
			}
			if (DDM<0){
				DDM+=12;
				DDY-=1;
			}
			VMO=DDY*12+DDM
			return VMO
		}
		function countdayslater(lastID,interval){
			date_1=new Date(lastID);
			date_2=new Date(date_1.getTime()+(interval)*1000*3600*24+8*1000*3600).toISOString();
			return date_2
		}
		function countneedvaccine(monthold){
			needtoapplylist=[];
			recvaccinelist={
				"0":['rHepB-1'],
				"1":['rHepB-2'],
				"2":['13PCV-1','5in1-1'],
				"4":['13PCV-2','5in1-2'],
				"5":['BCG'],
				"6":['rHepB-3','5in1-3'],
				"12":['MMR-1','Var-1','2HepA-1','13PCV-3'],
				"15":['JE-CV_LiveAtd-1'],
				"18":['2HepA-2','5in1-4'],
				"27":['JE-CV_LiveAtd-2'],
				"60":['DTaP-IPV-5','MMR-2']
			}
			monthlist=Object.keys(recvaccinelist)
			for (b=0;b<monthlist.length;b++){
				if (monthlist[b]<=monthold){
					for (c=0;c<recvaccinelist[monthlist[b]].length;c++){
						needtoapplylist.push(recvaccinelist[monthlist[b]][c])
					}
				}
			}
			return needtoapplylist
		}
		function countnextvaccine(monthold){
			recvaccinelist={
				"0":['rHepB-1'],
				"1":['rHepB-2'],
				"2":['13PCV-1','5in1-1'],
				"4":['13PCV-2','5in1-2'],
				"5":['BCG'],
				"6":['rHepB-3','5in1-3'],
				"12":['MMR-1','Var-1','2HepA-1','13PCV-3'],
				"15":['JE-CV_LiveAtd-1'],
				"18":['2HepA-2','5in1-4'],
				"27":['JE-CV_LiveAtd-2'],
				"60":['DTaP-IPV-5','MMR-2']
			}
			monthlist=Object.keys(recvaccinelist);
			nexttimevaccine=[];
			for (let b=0;b<monthlist.length;b++){
				if (monthlist[b]>monthold){
					nexttimevaccine=recvaccinelist[monthlist[b]];
					break;
				}
			}
			return nexttimevaccine
		}
		function comparevaccine(applyrecord,birth){
			old_array=countage(birth);
			monthold=(old_array[0]*12+old_array[1]+old_array[2]/30).toFixed(2)*1;
			ageold=countageold(birth);
			need_array=countneedvaccine(monthold);
			next_array=countnextvaccine(monthold);
			applylist=applyrecord_to_obj(applyrecord);
			returnobj={};
			returnobj['needtoapply']={};
			returnobj['nexttoapply']={};
			applylist_array=Object.keys(applylist);
			if (applylist_array.includes('13PCV-3')){
				PCV3ID=applylist['13PCV-3']['ID'];
				PCV3IDageold=countVageold2(birth,PCV3ID);
				if (PCV3IDageold<12){
					if (monthold>=12){
						need_array.push('13PCV-4')
					}
				}
			}
			applypro=countvacpro(applylist_array);
			needpro=countvacpro(need_array);
			if (monthold<216){
				for (d=0;d<need_array.length;d++){
					if (!applylist_array.includes(need_array[d])){
						returnobj['needtoapply'][need_array[d]]=countnextIDfunction(applylist,need_array[d],birth);
					} 
				}
				for (let ccc=0; ccc<next_array.length;ccc++){
					returnobj['nexttoapply'][next_array[ccc]]=countnextIDfunction(applylist,next_array[ccc],birth);
				}
			}
			return returnobj
		}
		function mkytocy(mky){
			mkyy=mky.substring(0,3);
			mkym=mky.substring(3,5);
			mkyd=mky.substring(5,7);
			cyy=mkyy*1+1911;
			cyd=cyy+'-'+mkym+'-'+mkyd;
			return new Date(cyd)
		}
		function cyaddttime(cy,year,month){
			cyd=new Date(cy);
			cyy=cyd.getFullYear();
			cym=cyd.getMonth()+1;
			cyd=cyd.getDate();
			cyy=cyy+year;
			cym=cym+month;
			if (cym>12){
				cym-=12
				cyy+=1
			}
			ncyd=cyy+'-'+cym+'-'+cyd;
			date_1=new Date(ncyd);
			date_2=new Date(date_1.getTime()+8*1000*3600);
			return date_2
		}
		function cytomky(cy){
			cyd=new Date(cy);
			cyy=cyd.getFullYear()-1911;
			cym=cyd.getMonth()+1;
			cyd=cyd.getDate();
			mky="000"+cyy;
			mky=mky.substring(mky.length-3,mky.length);
			mkm="00"+cym;
			mkm=mkm.substring(mkm.length-2,mkm.length);
			mkd="00"+cyd;
			mkd=mkd.substring(mkd.length-2,mkd.length);
			mkdate=mky+mkm+mkd;
			return mkdate
		}
		function countnextIDfunction(applylist,countnextID,birth){
			activevaccine=['MMR','MMR-1','MMR-2','Var-1','Var-2','JE-CV_LiveAtd-1','JE-CV_LiveAtd-2']
			birthcy=mkytocy(birth);
			ALD='';
			ALDNa='';
			applykeys=Object.keys(applylist);
			for (e=0;e<activevaccine.length;e++){
				if (applykeys.includes(activevaccine[e])){
					ALDN=new Date(applylist[activevaccine[e]]['ID']);
					if (ALD==''){
						ALD=ALDN;
						ALDNa=activevaccine[e];
					} else {
						if (ALDN>ALD){
							ALD=ALDN;
							ALDNa=activevaccine[e];
						}
					}
				}
			}
			if (vaccinelist.includes(countnextID)){
				if (countnextID=='rHepB-1'){
					LD='';
					recommandtime=birthcy;
					recommandtimeC='出生24小時內儘速';
					leastinterval=birthcy;
					leastintervalC='出生24小時內儘速';
				}
				if (countnextID=='rHepB-2'){
					if (applykeys.includes('rHepB-1')){
						LD=applylist['rHepB-1']['ID']
						recommandtime1=cyaddttime(LD,0,1);
						recommandtime2=cyaddttime(birthcy,0,1);
						if (recommandtime1>recommandtime2){
							recommandtime=recommandtime1;
						} else {
							recommandtime=recommandtime2;
						}
						recommandtimeC='1個月大(與第一劑間隔1個月)';
						leastinterval=countdayslater(LD,28);
						leastintervalC='間隔4週(28天)';
					} else {
						LD='';
						recommandtime='';
						recommandtimeC='未接種第一劑';
						leastinterval='';
						leastintervalC='未接種第一劑';
					}
				}
				if (countnextID=='rHepB-3'){
					if (applykeys.includes('rHepB-2')){
						LD=applylist['rHepB-2']['ID']
						recommandtime1=cyaddttime(LD,0,5);
						recommandtime2=cyaddttime(birthcy,0,6);
						if (recommandtime1>recommandtime2){
							recommandtime=recommandtime1;
						} else {
							recommandtime=recommandtime2;
						}
						recommandtimeC='6個月大(第二劑間隔5個月)';
						leastinterval1=countdayslater(LD,56);
						if (applykeys.includes('rHepB-1')){
							LD2=applylist['rHepB-1']['ID']
							leastinterval2=countdayslater(LD2,112);
						}
						if (leastinterval1>leastinterval2){
							leastinterval=leastinterval
						} else {
							leastinterval=leastinterval2
						}
						leastintervalC='與第二劑間隔56天且第1、第3劑應間隔至少16週';
					} else {
						LD='';
						recommandtime='';
						recommandtimeC='未接種第二劑';
						leastinterval='';
						leastintervalC='未接種第二劑';
					}
				}
				if (countnextID=='5in1-1'){
					LD='';
					recommandtime1=countdayslater(birthcy,60);
					recommandtime2=cyaddttime(birthcy,0,2);
					if (recommandtime1>recommandtime2){
						recommandtime=recommandtime1;
					} else {
						recommandtime=recommandtime2;
					}
					recommandtimeC='2個月';
					leastinterval=countdayslater(birthcy,42);
					leastintervalC='6週';
				}
				if (countnextID=='5in1-2'){
					if (applykeys.includes('5in1-1')){
						LD=applylist['5in1-1']['ID']
						recommandtime1=cyaddttime(LD,0,2);
						recommandtime2=cyaddttime(birthcy,0,4);
						if (recommandtime1>recommandtime2){
							recommandtime=recommandtime1;
						} else {
							recommandtime=recommandtime2;
						}
						recommandtimeC='4個月(與第一劑間隔2個月)';
						leastinterval=countdayslater(LD,28);
						leastintervalC='4週(與第一劑間隔28天)';
					} else {
						LD='';
						recommandtime='';
						recommandtimeC='未接種第一劑';
						leastinterval='';
						leastintervalC='未接種第一劑';
					}
				}
				if (countnextID=='5in1-3'){
					if (applykeys.includes('5in1-2')){
						LD=applylist['5in1-2']['ID']
						recommandtime1=cyaddttime(LD,0,2);
						recommandtime2=cyaddttime(birthcy,0,6);
						if (recommandtime1>recommandtime2){
							recommandtime=recommandtime1;
						} else {
							recommandtime=recommandtime2;
						}
						recommandtimeC='6個月(與第二劑間隔2個月)';
						leastinterval=countdayslater(LD,28);
						leastintervalC='4週(與第二劑間隔28天)';
					} else {
						LD='';
						recommandtime='';
						recommandtimeC='未接種第二劑';
						leastinterval='';
						leastintervalC='未接種第二劑';
					}
				}
				if (countnextID=='5in1-4'){
					if (applykeys.includes('5in1-3')){
						LD=applylist['5in1-3']['ID']
						recommandtime1=cyaddttime(LD,1,0);
						recommandtime2=cyaddttime(birthcy,1,6);
						if (recommandtime1>recommandtime2){
							recommandtime=recommandtime1;
						} else {
							recommandtime=recommandtime2;
						}
						recommandtimeC='18個月(與第三劑間隔1年)';
						leastinterval1=countdayslater(LD,180);
						leastinterval2=cyaddttime(birthcy,1,0);
						if (leastinterval1>leastinterval2){
							leastinterval=leastinterval1
						} else {
							leastinterval=leastinterval2
						}
						leastintervalC='間隔6個月(與第二劑間隔180天)且滿1歲後';
					} else {
						LD='';
						recommandtime='';
						recommandtimeC='未接種第三劑';
						leastinterval='';
						leastintervalC='未接種第三劑';
					}
				}
				if (countnextID=='13PCV-1'){
					LD='';
					recommandtime1=countdayslater(birthcy,60);
					recommandtime2=cyaddttime(birthcy,0,2);
						if (recommandtime1>recommandtime2){
							recommandtime=recommandtime1;
						} else {
							recommandtime=recommandtime2;
						}
					recommandtimeC='2個月大';
					leastinterval=countdayslater(birthcy,42);
					leastintervalC='6週大';
				}
				if (countnextID=='13PCV-2'){
					if (applykeys.includes('13PCV-1')){
						LD=applylist['13PCV-1']['ID']
						recommandtime1=cyaddttime(LD,0,2);
						recommandtime2=cyaddttime(birthcy,0,4);
						if (recommandtime1>recommandtime2){
							recommandtime=recommandtime1;
						} else {
							recommandtime=recommandtime2;
						}
						recommandtimeC='4個月大(第一劑間隔2個月)';
						leastinterval=countdayslater(LD,56);
						leastintervalC='間隔8週(56天)';
					} else {
						LD='';
						recommandtime='';
						recommandtimeC='未接種第一劑';
						leastinterval='';
						leastintervalC='未接種第一劑';
					}
				}
				if (countnextID=='13PCV-3'){
					if (applykeys.includes('13PCV-2')){
						LD=applylist['13PCV-2']['ID']
						recommandtime1=cyaddttime(LD,0,8);
						recommandtime2=cyaddttime(birthcy,1,0);
						if (recommandtime1>recommandtime2){
							recommandtime=recommandtime1;
						} else {
							recommandtime=recommandtime2;
						}
						recommandtimeC='12個月大(與第二劑間隔8個月)';
						leastinterval1=countdayslater(LD,56);
						leastinterval2=cyaddttime(birthcy,1,0);
						if (leastinterval1>leastinterval2){
							leastinterval=leastinterval1;
						} else {
							leastinterval=leastinterval2;
						}
						leastintervalC='間隔8週且滿1歲(與第二劑間隔56天)';
					} else {
						LD='';
						recommandtime='';
						recommandtimeC='未接種第二劑';
						leastinterval='';
						leastintervalC='未接種第二劑';
					}
				}
				if (countnextID=='13PCV-4'){
					if (applykeys.includes('13PCV-3')){
						LD=applylist['13PCV-3']['ID']
						recommandtime1=cyaddttime(LD,0,6);
						recommandtime2=cyaddttime(birthcy,1,0);
						if (recommandtime1>recommandtime2){
							recommandtime=recommandtime1;
						} else {
							recommandtime=recommandtime2;
						}
						recommandtimeC='12個月大(與第三劑間隔6個月)';
						leastinterval1=countdayslater(LD,56);
						leastinterval2=cyaddttime(birthcy,1,0);
						if (leastinterval1>leastinterval2){
							leastinterval=leastinterval1;
						} else {
							leastinterval=leastinterval2;
						}
						leastintervalC='間隔8週且滿1歲(與第三劑間隔56天)';
					} else {
						LD='';
						recommandtime='';
						recommandtimeC='未接種第二劑';
						leastinterval='';
						leastintervalC='未接種第二劑';
					}
				}
				if (countnextID=='BCG'){
					LD='';
					recommandtime=cyaddttime(birthcy,0,5);
					recommandtimeC='5個月';
					leastinterval=birthcy;
					leastintervalC='出生後';
				}
				if (countnextID=='MMR-1'){
					LD='';
					if (ALD==''){
						recommandtime=cyaddttime(birthcy,1,0);
						recommandtimeC='12個月';
						leastinterval=cyaddttime(birthcy,1,0);
						leastintervalC='12個月';
					} else {
						recommandtime1=cyaddttime(birthcy,1,0);
						recommandtime2=countdayslater(ALD,29);
						if (recommandtime1>recommandtime2){
							recommandtime=recommandtime1;
							leastinterval=recommandtime1;
							recommandtimeC='12個月';
							leastintervalC='12個月';
						} else {
							recommandtime=recommandtime2;
							leastinterval=recommandtime2;
							recommandtimeC='滿12個月且與'+ALDNa+'間隔28+1天';
							leastintervalC='滿12個月且與'+ALDNa+'間隔28+1天';
						}
					}
				}
				if (countnextID=='MMR-2'){
					if (applykeys.includes('MMR-1')){
						LD=applylist['MMR-1']['ID']
						if (ALD==''){
							recommandtime=cyaddttime(birthcy,5,0);
							recommandtimeC='滿5歲';
							leastinterval=countdayslater(LD,29);
							leastintervalC='隔4週(與第一劑間隔28+1天)';
						} else {
							recommandtime1=cyaddttime(birthcy,5,0);
							recommandtime2=countdayslater(ALD,29);
							if (recommandtime1>recommandtime2){
								recommandtime=recommandtime1;
								recommandtimeC='滿5歲';
							} else {
								recommandtime=recommandtime2;
								recommandtimeC='滿5歲且與'+ALDNa+'間隔28+1天';
							} 
							leastinterval1=countdayslater(ALD,29);
							leastinterval2=countdayslater(LD,29);
							if (leastinterval1>leastinterval2){
								leastinterval=leastinterval1;
								leastintervalC='隔4週(與第一劑間隔28+1天)';
							} else {
								leastinterval=leastinterval2;
								leastintervalC='與'+ALDNa+'間隔28天';
							} 
						}
					} else {
						LD='';
						recommandtime='';
						recommandtimeC='未接種第一劑';
						leastinterval='';
						leastintervalC='未接種第一劑';
					}
				}
				if (countnextID=='Var-1'){
					LD='';
					if (ALD==''){
						recommandtime=cyaddttime(birthcy,1,0);
						recommandtimeC='12個月';
						leastinterval=cyaddttime(birthcy,1,0);
						leastintervalC='12個月';
					} else {
						recommandtime1=cyaddttime(birthcy,1,0);
						recommandtime2=countdayslater(ALD,29);
						if (recommandtime1>recommandtime2){
							recommandtime=recommandtime1;
							leastinterval=recommandtime1;
							recommandtimeC='12個月';
							leastintervalC='12個月';
						} else {
							recommandtime=recommandtime2;
							leastinterval=recommandtime2;
							recommandtimeC='滿12個月且與'+ALDNa+'間隔28(+1)天';
							leastintervalC='滿12個月且與'+ALDNa+'間隔28(+1)天';
						}
					}
				}
				/*
				if (countnextID=='2HepA-1'){
					LD='';
					recommandtime=cyaddttime(birthcy,1,0);
					recommandtimeC='12個月';
					leastinterval=cyaddttime(birthcy,1,0);
					leastintervalC='12個月';
				}
				if (countnextID=='2HepA-2'){
					if (applykeys.includes('2HepA-1')){
						LD=applylist['2HepA-1']['ID']
						recommandtime1=cyaddttime(LD,0,6);
						recommandtime2=cyaddttime(birthcy,1,6);
						if (recommandtime1>recommandtime2){
							recommandtime=recommandtime1;
						} else {
							recommandtime=recommandtime2;
						}
						recommandtimeC='18個月(與第一劑間隔6個月)';
						leastinterval=cyaddttime(LD,0,6);
						leastintervalC='與第一劑間隔6個月';
					} else {
						LD='';
						recommandtime='';
						recommandtimeC='未接種第一劑';
						leastinterval='';
						leastintervalC='未接種第一劑';
					}
				}
				*/
				if (countnextID=='2HepA-1'){
					LD='';
					recommandtime=cyaddttime(birthcy,1,6);
					recommandtimeC='18個月';
					leastinterval=cyaddttime(birthcy,1,6);
					leastintervalC='18個月';
				}
				if (countnextID=='2HepA-2'){
					if (applykeys.includes('2HepA-1')){
						LD=applylist['2HepA-1']['ID']
						recommandtime1=cyaddttime(LD,0,6);
						recommandtime2=cyaddttime(birthcy,2,3);
						if (recommandtime1>recommandtime2){
							recommandtime=recommandtime1;
						} else {
							recommandtime=recommandtime2;
						}
						recommandtimeC='27個月(與第一劑間隔6個月)';
						leastinterval=cyaddttime(LD,0,6);
						leastintervalC='與第一劑間隔6個月';
					} else {
						LD='';
						recommandtime='';
						recommandtimeC='未接種第一劑';
						leastinterval='';
						leastintervalC='未接種第一劑';
					}
				}
				if (countnextID=='JE-CV_LiveAtd-1'){
					LD='';
					if (ALD==''){
						recommandtime=cyaddttime(birthcy,1,3);
						recommandtimeC='15個月';
						leastinterval=cyaddttime(birthcy,1,0);
						leastintervalC='12個月';
					} else {
						recommandtime1=cyaddttime(birthcy,1,3);
						recommandtime2=countdayslater(ALD,29);
						if (recommandtime1>recommandtime2){
							recommandtime=recommandtime1;
							recommandtimeC='15個月';
						} else {
							recommandtime=recommandtime2;
							recommandtimeC='滿15個月且與'+ALDNa+'間隔28+1天';
						}
						leastinterval1=cyaddttime(birthcy,1,0);
						leastinterval2=countdayslater(ALD,29);
						if (leastinterval1>leastinterval2){
							leastinterval=leastinterval1;
							leastintervalC='12個月';
						} else {
							leastinterval=leastinterval2;
							leastintervalC='滿12個月且與'+ALDNa+'間隔28+1天';;
						} 
					}
				}
				if (countnextID=='JE-CV_LiveAtd-2'){
					if (applykeys.includes('JE-CV_LiveAtd-1')){
						LD=applylist['JE-CV_LiveAtd-1']['ID']
						if (ALD==''){
							recommandtime1=cyaddttime(LD,1,0);
							recommandtime1=countdayslater(recommandtime1,1);
							recommandtime2=cyaddttime(birthcy,2,3);
							recommandtime2=countdayslater(recommandtime2,1);
							if (recommandtime1>recommandtime2){
								recommandtime=recommandtime1;
							} else {
								recommandtime=recommandtime2;
							}
							recommandtimeC='27個月+1天(與第一劑間隔12個月+1天)';
							leastinterval=cyaddttime(LD,1,0);
							leastinterval=countdayslater(leastinterval,1);
							leastintervalC='與第一劑間隔12個月+1天';
						} else {
							recommandtime1=cyaddttime(LD,1,0);
							recommandtime1=countdayslater(recommandtime1,1);
							recommandtime2=countdayslater(ALD,29);
							if (recommandtime1>recommandtime2){
								recommandtime=recommandtime1;
								recommandtimeC='27個月+1天(與第一劑間隔12個月+1天)';
							} else {
								recommandtime=recommandtime2;
								recommandtimeC='第一劑間隔12個月+1天且與'+ALDNa+'間隔28+1天';
							} 
							leastinterval1=cyaddttime(LD,1,0);
							leastinterval1=countdayslater(leastinterval1,1);
							leastinterval2=countdayslater(ALD,29);
							if (leastinterval1>leastinterval2){
								leastinterval=leastinterval1;
								leastintervalC='與第一劑間隔12個月+1天';
							} else {
								leastinterval=leastinterval2;
								leastintervalC='與第一劑間隔12個月+1天且與'+ALDNa+'間隔28天';
							} 
						}
					} else {
						LD='';
						recommandtime='';
						recommandtimeC='未接種第一劑';
						leastinterval='';
						leastintervalC='未接種第一劑';
					}
				}
				if (countnextID=='DTaP-IPV-5'){
					LD='';
					recommandtime=cyaddttime(birthcy,5,0);
					recommandtimeC='滿5歲';
					leastinterval=cyaddttime(birthcy,4,0);
					leastintervalC='滿4歲';
				}
				temparray={};
				temparray.name=countnextID;
				temparray.LD=LD;
				temparray.recommandtime=recommandtime;
				temparray.recommandtimeC=recommandtimeC;
				temparray.leastinterval=leastinterval;
				temparray.leastintervalC=leastintervalC;
				now0=new Date();
				nowy=now0.getFullYear();
				nowm=now0.getMonth()+1;
				nowd=now0.getDate();
				nowm= nowm.toString().padStart(2, '0');
				nowd= nowd.toString().padStart(2, '0');
				now=new Date(nowy.toString()+'-'+nowm.toString()+'-'+nowd.toString()+"T15:00:00.000Z");
				if (now>=new Date(leastinterval)){
					thevacpro=vacnameprolist[countnextID]
					pass=true
					for (zz=0;zz<thevacpro.length;zz++){
						apro=Math.ceil(applypro[thevacpro[zz]]);
						npro=Math.ceil(needpro[thevacpro[zz]]);
						if (apro<npro){
							pass=false
						}
					}
					if (pass){
						if (now>=new Date(recommandtime)){
							temparray.allsug='?_O';
							temparray.allsugC='請檢查是否有接種替代疫苗，若無建議接種';
						} else {
							temparray.allsug='?_▲';
							temparray.allsugC='請檢查是否有接種替代疫苗，若無可接種(符合最短間隔)';
						}
					} else {
						if (now>=new Date(recommandtime)){
							temparray.allsug='O';
							temparray.allsugC='建議接種';
						} else {
							temparray.allsug='▲';
							temparray.allsugC='僅符合最短接種時程';
						}
					}
				} else {
					temparray.allsug='X';
					temparray.allsugC='不符合接種時程';
				}
				return temparray
			} 
		}
		function countvacpro(array){
		vacpro={}
		for (aa=0;aa<vacprolist.length;aa++){
			vacpro[vacprolist[aa]]=0;
		}
		for (ab=0;ab<array.length;ab++){
			thevacname=array[ab];
			if (Object.keys(vacnameprolist).includes(thevacname)){
				thevacprolist=vacnameprolist[thevacname];
				if (["JE-1","JE-2","JE-3","JE-4","JE-VC_Inactd-1","JE-VC_Inactd-2","JE-VC_Inactd-3","JE-VC_Inactd-4"].includes(thevacname)){
					vproc=0.3;
				} else {
					vproc=1;
				}
				for (ac=0;ac<thevacprolist.length;ac++){
					vacpro[thevacprolist[ac]]+=vproc;
				}
			}
		}
		return vacpro
	}
	function countflu(result,birth){
		now=new Date();
		nowy=now.getFullYear();
		nowm=now.getMonth()+1;
		if (nowm>=10){
			sy=nowy;
		} else {
			sy=nowy-1;
		}
		flustarttime=new Date(sy+'-10-01 ');
		old_array=countage(birth);
		monthold=(old_array[0]*12+old_array[1]+old_array[2]/30).toFixed(2)*1;
		retobj={};
		errmsg='';
		flulist=[];
		if (monthold>=6){
			for (f=0;f<result['ApplyRecord'].length;f++){
				SRVC=result['ApplyRecord'][f]['SRVC'];
				if (SRVC.includes('Flu')){
					flulist.push(result['ApplyRecord'][f]);
				}
			}
			if (flulist.length==0){
				suggest="O";
				if (monthold<108){
					errmsg='未滿9歲,需接種第二劑';
				} else {
					errmsg='不曾接種';
				}
				LD="";
				LDsite="";
			} else {
				LD=flulist[flulist.length-1]['ID'];
				LDdate=new Date(LD);
				if (LDdate>=flustarttime){
					if (flulist.length==1){
						if (monthold<108){
							if (now>=new Date(countdayslater(LDdate,28))){
								suggest="2";
								LDsite=flulist[flulist.length-1]['ON'];
								errmsg='第二劑,間隔滿28天';
							} else {
								suggest="X";
								LDsite=flulist[flulist.length-1]['ON'];
								errmsg='第二劑間隔未滿28天';
							}
						} else {
							suggest="X";
							LDsite=flulist[flulist.length-1]['ON'];
							errmsg='當年度已接種';
						}
					} else {
						suggest="X";
						LDsite=flulist[flulist.length-1]['ON'];
						errmsg='當年度已接種';
					}
				} else {
					suggest="O";
					errmsg='當年度未接種';
					LDsite=flulist[flulist.length-1]['ON'];
				}
			}
				
		} else {
			suggest="X";
			LD="";
			LDsite="";
			errmsg='未滿6個月';
		}
		retobj['suggest']=suggest;
		retobj['LD']=LD;
		retobj['LDsite']=LDsite;
		retobj['errmsg']=errmsg;
		return retobj
	}
	function countPV(result,birth){
		ageold=countageold(birth);
		PPVlist=[];
		PCVlist=[];
		for (g=0;g<result['ApplyRecord'].length;g++){
			SRVC=result['ApplyRecord'][g]['SRVC'];
			if (SRVC.includes('PPV')){
				PPVlist.push(result['ApplyRecord'][g]);
			}
			if (SRVC.includes('PCV')){
				if (countVageold(birth,result['ApplyRecord'][g]['ID'])>18){
					PCVlist.push(result['ApplyRecord'][g]);
				}
			}
		}
		if (PPVlist.length>0){
			PPVsuggest='X';
			PPVcomment='已接種過PPV';
			PPVLD=PPVlist[PPVlist.length-1]['ID'];
			PPVLDS=PPVlist[PPVlist.length-1]['ON'];
		} else {
			if (ageold>=65){
				if (PCVlist.length>0){
					PCVLD=PCVlist[PCVlist.length-1]['ID'];
					now=new Date();
					if (now>=cyaddttime(PCVLD,1,0)){
						PPVsuggest='O';
						PPVcomment='已接種過PCV13,間隔滿1年';
						PPVLD="";
						PPVLDS="";
					} else {
						PPVsuggest='X';
						PPVcomment='已接種過PCV1,間隔未滿1年';
						PPVLD="";
						PPVLDS="";
					}
				} else {
					PPVsuggest='▲';
					PPVcomment='年滿65歲,優先接種PCV13';
					PPVLD="";
					PPVLDS="";
				}
			} else if (ageold>=50 && ageold<65){
				PPVsuggest='▲';
				PPVcomment='55-64專案';
				PPVLD="";
				PPVLDS="";
			} else {
				PPVsuggest='X';
				PPVcomment='未滿50歲,無法施打PPV';
				PPVLD="";
				PPVLDS="";
			}
		}
		if (PCVlist.length>0){
			PCVsuggest='X';
			PCVcomment='已接種過PCV';
			PCVLD=PCVlist[PCVlist.length-1]['ID'];
			PCVLDS=PCVlist[PCVlist.length-1]['ON'];
		} else {
			if (ageold>=65){
				if (PPVlist.length>0){
					PPVLD=PPVlist[PPVlist.length-1]['ID'];
					now=new Date();
					if (now>=cyaddttime(PPVLD,1,0)){
						PCVsuggest='O';
						PCVcomment='已接種過PPV,間隔滿1年';
						PCVLD="";
						PCVLDS="";
					} else {
						PCVsuggest='X';
						PCVcomment='已接種過PPV,間隔未滿1年';
						PCVLD="";
						PCVLDS="";
					}
				} else {
					PCVsuggest='O';
					PCVcomment='可接種PCV';
					PCVLD="";
					PCVLDS="";
				}
			} else {
				PCVsuggest='X';
				PCVcomment='未滿65歲,無法施打PCV';
				PCVLD="";
				PCVLDS="";
			}
		}
		retobj={};
		retobj['PCV']={}
		retobj['PCV']['PCVsuggest']=PCVsuggest;
		retobj['PCV']['PCVcomment']=PCVcomment;
		retobj['PCV']['PCVLD']=PCVLD;
		retobj['PCV']['PCVLDS']=PCVLDS;
		retobj['PPV']={}
		retobj['PPV']['PPVsuggest']=PPVsuggest;
		retobj['PPV']['PPVcomment']=PPVcomment;
		retobj['PPV']['PPVLD']=PPVLD;
		retobj['PPV']['PPVLDS']=PPVLDS;
		return retobj
	}
	function countCOV(result,birth){
		old_array=countage(birth);
		monthold=(old_array[0]*12+old_array[1]+old_array[2]/30).toFixed(2)*1;
		retobj={};
		if (monthold>6){
			CoVlist=[];
			for (h=0;h<result['ApplyRecord'].length;h++){
				SRVC=result['ApplyRecord'][h]['SRVC'];
				if (SRVC.includes('CoV_')){
					CoVlist.push(result['ApplyRecord'][h]);
				}
			}
			if (CoVlist.length>0){
				theSRVC=CoVlist[CoVlist.length-1]['SRVC'];
				retobj['count']=CoVlist.length;
				COVLD=CoVlist[CoVlist.length-1]['ID'];
				retobj['LD']=COVLD;
				retobj['LDsite']=CoVlist[CoVlist.length-1]['ON'];
				retobj['LDtype']=theSRVC;
				now=new Date();
				if (now>=cyaddttime(COVLD,0,3)){
					retobj['suggest']='O';
				} else {
					retobj['suggest']='X';
				}
			
			} else {
				retobj['count']=CoVlist.length;
				retobj['LD']="";
				retobj['LDsite']="";
				retobj['LDtype']="";
				retobj['suggest']='O';
			}
		} else {
			retobj['count']=0;
			retobj['LD']="";
			retobj['LDsite']="";
			retobj['LDtype']="<6個月不接種新冠疫苗";
			retobj['suggest']='X';
		}
		
		return retobj
	}
	function getallneedvaccine(result,birth){
		returnobj={};
		returnobj['routine']=comparevaccine(result,birth);
		returnobj['flu']=countflu(result,birth);
		returnobj['PV']=countPV(result,birth);
		returnobj['CoV']=countCOV(result,birth);
		return returnobj
	}
	function getvaccinelist(pbirth,ijson){

		result=ijson;
		vaccinesug=getallneedvaccine(ijson,pbirth);
		theretobj={};
		theretobj['patientName']=thename;
		theretobj['vaccinesuggestion']=vaccinesug;
		theretobj['niisapplylist']=result;
		
		//changetoutc
		
		if (testmode){
			return theretobj
		} else {
			theretobj_string=JSON.stringify(theretobj);
			return theretobj_string
		}
	}
	
}
	
	function httpGet(Url) {
		var xmlHttp = new XMLHttpRequest();
		xmlHttp.open( "GET", Url, false );
		xmlHttp.send( null );
		return xmlHttp.responseText;
	}
	
	function showvacwindow(res,patientidbirth){
		let jres=JSON.parse(res)
		if (document.getElementById('create_niisdrag')!=null){
			document.getElementById('create_niisdrag').remove();
		}
		thewidth=610;
		theheight=500;
		borderx=20;
		bordery=150;
		var myDraggable = document.createElement('div');
		myDraggable.id='create_niisdrag';
		myDraggable.style.width = thewidth+'px';
		myDraggable.style.left=(window.innerWidth-thewidth)/2 +'px';
		
		myDraggable.style.top = bordery +'px';
		myDraggable.style.background = '#f9f9f9';
		myDraggable.style.border = '1px solid #ccc';
		myDraggable.style.position = 'absolute';
		myDraggable.style.zIndex = '9999';
		
		let my=patientidbirth.substring(0,3);
		let mm=patientidbirth.substring(3,5);
		let md=patientidbirth.substring(5,7);
		let agey=new Date().getFullYear()-1911-my;
		let agem=new Date().getMonth()+1-mm;
		let aged=new Date().getDate()-md;
		if (aged<0){
			agem-=1;
			aged+=30;
		}
		if (agem<0){
			agey-=1;
			agem+=12;
		}
		let agec="";
		if (agey==0){
			agec=agem+'月'+aged+'天';
		} else {
			agec=agey+'歲'+agem+'月'+aged+'天';
		}
		let xx=2;
		let yy=2;
		let bb=2;
		div_name = addtext(xx,yy,40,25);
		div_name.textContent='姓名:';
		xx=xx+40+bb;
		div_name = addtext(xx,yy,500,25);
		div_name.textContent=jres.patientName+"("+agec+")";
		div_name.style.textAlign='left';
		
		div_exit = addbutton(585,yy,25,25);
		div_exit.textContent='X';
		div_exit.addEventListener('click',function() {
			if (document.getElementById('create_niisdrag')!=null){
				document.getElementById('create_niisdrag').remove();
			}
		});
		xx=xx+40+bb;
		xx=2
		yy+=25
		div_flu = addtext(xx,yy,40,25);
		div_flu.textContent='flu:';
		div_flu.style.textAlign='right';
		xx=xx+40+bb;
		div_fluc = addtext(xx,yy,110,25);
		div_fluc.textContent=cytomky(jres.vaccinesuggestion.flu.LD)+"("+jres.vaccinesuggestion.flu.suggest+")";
		div_fluc.style.textAlign='left';
		if (jres.vaccinesuggestion.flu.suggest=="O" || jres.vaccinesuggestion.flu.suggest=="2"){
			div_fluc.style.color="blue";
		}
		div_fluc.title=jres.vaccinesuggestion.flu.errmsg+"\n上次接種時間:"+cytomky(jres.vaccinesuggestion.flu.LD)+"\n上次接種地點:"+jres.vaccinesuggestion.flu.LDsite;
		xx=xx+110+bb;
		div_PPV = addtext(xx,yy,40,25);
		div_PPV.textContent='PPV:';
		div_PPV.style.textAlign='right';
		xx=xx+40+bb;
		div_PPVc = addtext(xx,yy,110,25);
		div_PPVc.textContent=cytomky(jres.vaccinesuggestion.PV.PPV.PPVLD)+"("+jres.vaccinesuggestion.PV.PPV.PPVsuggest+")";
		div_PPVc.style.textAlign='left';
		if (jres.vaccinesuggestion.PV.PPV.PPVsuggest=="O"){
			div_PPVc.style.color="blue";
		}
		div_PPVc.title=jres.vaccinesuggestion.PV.PPV.PPVcomment+"\n上次接種時間:"+cytomky(jres.vaccinesuggestion.PV.PPV.PPVLD)+"\n上次接種地點:"+jres.vaccinesuggestion.PV.PPV.PPVLDS;
		xx=xx+110+bb;
		div_PCV = addtext(xx,yy,40,25);
		div_PCV.textContent='PCV:';
		div_PCV.style.textAlign='right';
		xx=xx+40+bb;
		div_PCVc = addtext(xx,yy,110,25);
		div_PCVc.textContent=cytomky(jres.vaccinesuggestion.PV.PCV.PCVLD)+"("+jres.vaccinesuggestion.PV.PCV.PCVsuggest+")";
		div_PCVc.style.textAlign='left';
		if (jres.vaccinesuggestion.PV.PCV.PCVsuggest=="O"){
			div_PCVc.style.color="blue";
		}
		div_PCVc.title=jres.vaccinesuggestion.PV.PCV.PCVcomment+"\n上次接種時間:"+cytomky(jres.vaccinesuggestion.PV.PCV.PCVLD)+"\n上次接種地點:"+jres.vaccinesuggestion.PV.PCV.PCVLDS;
		xx=xx+110+bb;
		div_COV = addtext(xx,yy,40,25);
		div_COV.textContent='COV:';
		div_COV.style.textAlign='right';
		xx=xx+40+bb;
		div_COVc = addtext(xx,yy,110,25);
		div_COVc.textContent=cytomky(jres.vaccinesuggestion.CoV.LD)+"("+jres.vaccinesuggestion.CoV.suggest+")";
		div_COVc.style.textAlign='left';
		if (jres.vaccinesuggestion.CoV.suggest=="O"){
			div_COVc.style.color="blue";
		}
		div_COVc.title="共接種"+jres.vaccinesuggestion.CoV.count+"劑\n上次接種時間:"+cytomky(jres.vaccinesuggestion.CoV.LD)+"\n上次接種地點:"+jres.vaccinesuggestion.CoV.LDsite;
		xx=2
		yy+=25
		div_ti = addtext(xx,yy,500,25);
		div_ti.textContent='1. 疫苗接種紀錄'
		div_ti.style.textAlign='left';
		yy+=25
		tab_his = addtable(xx,yy,600,150,["劑次","日期","地點"]);
		for (let i=0;i<jres.niisapplylist.ApplyRecord.length;i++){
			let newrow = tab_his.insertRow(1);
			let rec=jres.niisapplylist.ApplyRecord[i];
			let rowdata=[rec.SRVC,cytomky(rec.ID),rec.ON];
			for (let j=0;j<rowdata.length;j++){
				let newcell = document.createElement('td');
				newcell.style.border = "1px solid #ddd";
				newcell.style.minWidth = "100px";
				newcell.style.whiteSpace = "nowrap";
				newcell.textContent = rowdata[j];
				newrow.appendChild(newcell);
			}
		}
		yy+=150
		div_ti = addtext(xx,yy,500,25);
		div_ti.textContent='2. 應接種疫苗'
		div_ti.style.textAlign='left';
		yy+=25
		tab_rou = addtable(xx,yy,600,150,['常規疫苗','上次接種','檢核','建議接種時間','最小接種時間']);
		needkeys=Object.keys(jres.vaccinesuggestion.needtoapply);
		for (let i=0;i<needkeys.length;i++){
			let needv=jres.vaccinesuggestion.needtoapply[needkeys[i]];
			let newrow = document.createElement('tr');
			let rowdata=[needv.name,cytomky(needv.LD),needv.allsug,cytomky(needv.recommandtime),cytomky(needv.leastinterval)];
			for (let j=0;j<rowdata.length;j++){
				let newcell = document.createElement('td');
				newcell.style.border = "1px solid #ddd";
				newcell.style.minWidth = "100px";
				newcell.style.whiteSpace = "nowrap";
				newcell.textContent = rowdata[j];
				if (j==2){
					newcell.title=needv.allsugC;
				} else if (j==3){
					newcell.title=needv.recommandtimeC;
				} else if (j==4){
					newcell.title=needv.leastintervalC;
				}
				newrow.appendChild(newcell);
			}
			tab_rou.appendChild(newrow);
		}
		yy+=155
		nextkeys=Object.keys(jres.vaccinesuggestion.nexttoapply);
		nexttxt=addtext(xx,yy,600,25);
		nexttxt.style.textAlign='left';
		if (nextkeys.length==0){
			nexttxt.textContent="已完成常規疫苗"
			nexttxt.style.color="blue";
		} else {
			nexttxt.textContent="未完成常規疫苗"
			nexttxt.style.color="red";
			for (let i=0;i<nextkeys.length;i++){
				yy+=25
				let newnv=jres.vaccinesuggestion.nexttoapply[nextkeys[i]];
				let newtxt=addtext(xx,yy,600,25);
				newtxt.style.textAlign='left';
				newtxt.textContent=newnv.name+"，建議:"+cytomky(newnv.recommandtime)+"，最短:"+cytomky(newnv.leastinterval);
				let tisug='上次接種日期: '+cytomky(newnv.LD);
				tisug=tisug+'\n建議接種時程: ' + cytomky(newnv.recommandtime);
				tisug=tisug+'\n建議時程說明: ' + newnv.recommandtimeC;
				tisug=tisug+'\n最短接種時程: ' + cytomky(newnv.leastinterval);
				tisug=tisug+'\n最短時程說明: ' + newnv.leastintervalC;
				newtxt.title=tisug;
			}
		}
		yy+=30;
		myDraggable.style.height = yy+'px';
		document.body.insertBefore(myDraggable,document.body.firstChild);
	
		
		function addtext(xx,yy,ww,hh){
			let div=document.createElement('div');
			div.style.width = ww+'px';
			div.style.height = hh+'px';
			div.style.left = xx+'px';
			div.style.top = yy+'px';
			div.style.position = 'absolute';
			div.style.textAlign='center';
			myDraggable.appendChild(div);
			return div
		}
		function addbutton(xx,yy,ww,hh){
			let div=document.createElement('button');
			div.style.width = ww+'px';
			div.style.height = hh+'px';
			div.style.left = xx+'px';
			div.style.top = yy+'px';
			div.style.position = 'absolute';
			div.style.textAlign='center';
			myDraggable.appendChild(div);
			return div
		}
		
		function addtable(xx,yy,ww,hh,title){
			let div=document.createElement("div");
			div.style.borderCollapse = "collapse";
			div.style.width = ww+'px';
			div.style.height = hh+'px';
			div.style.left = xx+'px';
			div.style.top = yy+'px';
			div.style.position = 'absolute';
			div.style.textAlign='center';
			div.style.overflowY = "auto";
			div.style.overflowX = "scroll";
			div.style.border = "1px solid";

			let table = document.createElement('table');
			let thead = document.createElement('thead');
			let headerRow = document.createElement('tr');
			for (let i=0;i<title.length;i++){
				let headerCell1 = document.createElement('th');
				headerCell1.textContent = title[i];
				headerCell1.style.border = "1px solid #ddd";
				headerCell1.style.backgroundColor = "#f2f2f2";
				headerCell1.style.minWidth = "100px";
				headerCell1.style.textAlign = "center";
				headerCell1.style.whiteSpace = "nowrap";
				headerCell1.style.position = "sticky";
				headerCell1.style.top = "0";
				headerRow.appendChild(headerCell1);
			}
			
			thead.appendChild(headerRow);
			table.appendChild(thead);
			div.appendChild(table);
			myDraggable.appendChild(div);
			return table
		}
		function cytomky(cy){
			if (cy==""){
				return "不曾"
			}
			try {
				cyd=new Date(cy);
				cyy=cyd.getFullYear()-1911;
				cym=cyd.getMonth()+1;
				cyd=cyd.getDate();
				mky="000"+cyy;
				mky=mky.substring(mky.length-3,mky.length);
				mkm="00"+cym;
				mkm=mkm.substring(mkm.length-2,mkm.length);
				mkd="00"+cyd;
				mkd=mkd.substring(mkd.length-2,mkd.length);
				mkdate=mky+mkm+mkd;
				return mkdate
			} catch (e) {
				return cy
			}
		}
	}
})();



